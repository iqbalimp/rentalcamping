<?php
Class Not extends Ci_Controller{
    
    
    
    function index(){
        $this->load->view('notfound');
    }
    
    
}
?>

