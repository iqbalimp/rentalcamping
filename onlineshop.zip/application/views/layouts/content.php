<div class="content-homepage">
      <div class="container">

        <div class="row">
          <div class="col-md-6">
            <h3 class="header-title">NEW ARRIVAL</h3>
          </div>
          <div class="col-md-6">
            <ul class="menu-right nav pull-right">
              <li><a href="#">WOMAN</a>
              <li><a href="#">MAN</a>
              <li><a href="#">ACCESSORIES</a>
              <li><a href="#"><span class="fa fa-th-list"></span></a>
              <li><a href="#"><span class="fa fa-th-large"></span></a>
          </div>
        </div>

        <div class="row">

          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-1.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-2.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-2.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-1.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
        </div>
        <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-2.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-2.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-1.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
          <div class="ch-produk-item col-md-3">
            <span class="badge-item">SALE</span>
            <div class="link-action">
              <a href="#" class="btn-cart btn"><span class="fa fa-shopping-cart"></span> ADD TO CART</a>
              <a href="#" class="btn-view btn"><span class="fa fa-eye"></span></a>
              <a href="#" class="btn-like btn"><span class="fa fa-heart"></span></a>
            </div>
            <img class="img-produk-item img-responsive" src="<?php echo base_url()?>front/img/produk-1.png" />
            <a href="#"><h4 class="text-center">Summer Jacket</h4></a>
            <p class="text-center">Rp. 290.000,00-</p>
          </div>
        </div>

      </div>
    </div><!-- content-homepage -->