<div class="features-homepage container">
    <div class="row">
        <div class="fh-item col-md-3">
            <img src="<?php echo base_url() ?>front/img/fh-1.png" class="fhi-icon pull-left img-responsive" />
            <h5>FREE SHIPMENT</h5>
            <h6>GRATIS BIAYA KIRIM SE INDONESIA</h6>
        </div>
        <div class="fh-item col-md-3">
            <img src="<?php echo base_url() ?>front/img/fh-2.png" class="fhi-icon pull-left img-responsive" />
            <h5>FREE GIFT VOUCHER</h5>
            <h6>DOOR PRIZE ANYTIME</h6>
        </div>
        <div class="fh-item col-md-3">
            <img src="<?php echo base_url() ?>front/img/fh-3.png" class="fhi-icon pull-left img-responsive" />
            <h5>FULL SUPPORT</h5>
            <h6>DAPATKAN 24 JAM FREE SUPPORT</h6>
        </div>
        <div class="fh-item col-md-3">
            <img src="<?php echo base_url() ?>front/img/fh-4.png" class="fhi-icon pull-left img-responsive" />
            <h5>SECURITY PAYMENT</h5>
            <h6>PENGUNCIAN CREDIT CARD</h6>
        </div>
    </div><!-- row -->
</div><!-- features-homepage -->